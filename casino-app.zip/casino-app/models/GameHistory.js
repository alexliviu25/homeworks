// models/GameHistory.js

const mongoose = require('mongoose');

const gameHistorySchema = new mongoose.Schema({
  game: { type: String, required: true }, // 'slot' or 'coinflip'
  symbols: [String], // for slot
  result: String,    // for coinflip
  bet: Number,
  win: Number,
  playedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('GameHistory', gameHistorySchema);

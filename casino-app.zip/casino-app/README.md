# 🎰 Casino Slot Machine App

A simple web-based slot machine game built with **Node.js**, **Express**, and **MongoDB**.  
Made for my university license project.

## 🛠️ Technologies Used
- Node.js
- Express
- MongoDB + Mongoose
- HTML + Vanilla JS (no frameworks)

## 🚀 How to Run

### 1. Start MongoDB
Make sure MongoDB is running. (It runs automatically as a Windows service.)

### 2. Install dependencies
```bash
npm install

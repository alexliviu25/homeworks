// games/coinflip.js

function flip(bet, guess) {
  const result = Math.random() < 0.5 ? 'heads' : 'tails';
  const win = (result === guess) ? bet * 2 : 0;
  return { result, win };
}

module.exports = { flip };

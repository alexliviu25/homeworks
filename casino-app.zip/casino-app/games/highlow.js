// /games/highlow.js
function drawCard() {
  return Math.floor(Math.random() * 13) + 1; // 1 to 13
}

function play(bet, guess) {
  const current = drawCard();
  let next = drawCard();

  // Ensure next is different to avoid boring ties
  while (next === current) {
    next = drawCard();
  }

  const isHigher = next > current;
  const win = (
    (guess === 'higher' && isHigher) ||
    (guess === 'lower' && !isHigher)
  ) ? Math.floor(bet * 1.5) : 0;

  return { current, next, guess, win };
}

module.exports = { play };

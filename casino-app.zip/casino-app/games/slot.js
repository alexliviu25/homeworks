function play(bet) {
  const symbols = ['🍒', '🍋', '🔔', '⭐', '7️⃣'];
  const spin = [
    symbols[Math.floor(Math.random() * symbols.length)],
    symbols[Math.floor(Math.random() * symbols.length)],
    symbols[Math.floor(Math.random() * symbols.length)],
  ];

  let win = 0;
  if (spin[0] === spin[1] && spin[1] === spin[2]) {
    win = bet * 5;
  } else if (spin[0] === spin[1] || spin[1] === spin[2] || spin[0] === spin[2]) {
    win = bet * 2;
  }

  return {
    spin,
    win
  };
}

module.exports = { play };

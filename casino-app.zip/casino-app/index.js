const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const User = require('./models/User');
const GameHistory = require('./models/GameHistory');
const slotGame = require('./games/slot');
const coinflipGame = require('./games/coinflip');
const highlowGame = require('./games/highlow'); // ✅ New import

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

mongoose.connect('mongodb://127.0.0.1:27017/casino', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ Connected to MongoDB'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// ✅ Init user
app.get('/init', async (req, res) => {
  let user = await User.findOne();
  if (!user) {
    user = new User();
    await user.save();
  }
  res.json(user);
});

// ✅ Get balance
app.get('/balance', async (req, res) => {
  const user = await User.findOne();
  res.json({ balance: user.balance });
});

// ✅ Slot Machine
app.post('/play/slot', async (req, res) => {
  const user = await User.findOne();
  const bet = req.body.bet;

  if (user.balance < bet) {
    return res.status(400).json({ message: 'Insufficient balance' });
  }

  const result = slotGame.play(bet);
  user.balance += result.win - bet;
  await user.save();

  const history = new GameHistory({
    game: 'slot',
    symbols: result.spin,
    bet,
    win: result.win
  });
  await history.save();

  res.json({ result, balance: user.balance });
});

// ✅ Coin Flip
app.post('/play/coinflip', async (req, res) => {
  const user = await User.findOne();
  const { bet, guess } = req.body;

  if (user.balance < bet) {
    return res.status(400).json({ message: 'Insufficient balance' });
  }

  const result = coinflipGame.flip(bet, guess);
  user.balance += result.win - bet;
  await user.save();

  const history = new GameHistory({
    game: 'coinflip',
    result: result.result,
    bet,
    win: result.win
  });
  await history.save();

  res.json({ result, balance: user.balance });
});

// ✅ High or Low
app.post('/play/highlow', async (req, res) => {
  const user = await User.findOne();
  const { bet, guess } = req.body;

  if (user.balance < bet) {
    return res.status(400).json({ message: 'Insufficient balance' });
  }

  const result = highlowGame.play(bet, guess);
  user.balance += result.win - bet;
  await user.save();

  const history = new GameHistory({
    game: 'highlow',
    result: `${result.current} → ${result.next} (${guess})`,
    bet,
    win: result.win
  });
  await history.save();

  res.json({ result, balance: user.balance });
});

// ✅ Reset
app.post('/reset', async (req, res) => {
  const user = await User.findOne();
  if (user) {
    user.balance = 1000;
    await user.save();
    res.json({ message: 'Balance reset', balance: user.balance });
  } else {
    res.status(404).json({ message: 'User not found' });
  }
});

// ✅ History
app.get('/history', async (req, res) => {
  const history = await GameHistory.find().sort({ playedAt: -1 }).limit(10);
  res.json(history);
});

// ✅ Start Server
app.listen(PORT, () => {
  console.log(`🎰 Server running on http://localhost:${PORT}`);
});
